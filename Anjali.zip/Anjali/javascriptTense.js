function openFormPast() {
    document.getElementById("myFormPast").style.display = "block";
  }
  
  function openFormPresent() {
    document.getElementById("myFormPresent").style.display = "block";
  }

  function openFormFuture() {
    document.getElementById("myFormFuture").style.display = "block";
  }

  function closeForm() {
    document.getElementById("myFormPast").style.display = "none";
    document.getElementById("myFormPresent").style.display = "none";
    document.getElementById("myFormFuture").style.display = "none";
  }