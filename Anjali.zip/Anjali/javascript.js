function timeStamp()
{
    var name = window.localStorage.getItem("name");
    var date = window.localStorage.getItem("date");
    alert("Username : "+name+ " \n Date : "+date);


    
}